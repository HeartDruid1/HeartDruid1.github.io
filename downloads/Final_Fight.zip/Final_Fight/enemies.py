#enemies for Final_Fight.py

def BrilliantBlue():
    name = "Brilliant Blue"
    maxHealth = 90
    health = maxHealth
    attack = 25
    maxEnergy = 50
    energy = maxEnergy

    return [name,health,maxHealth,attack,energy,maxEnergy]

def ShadowKnight():
    name = "Shadow Knight"
    maxHealth = 100
    health = maxHealth
    attack = 35
    maxEnergy = 75
    energy = maxEnergy

    return [name,health,maxHealth,attack,energy,maxEnergy]

def BlackMagic():
    name = "Black Magic"
    maxHealth = 110
    health = maxHealth
    attack = 40
    maxEnergy = 85
    energy = maxEnergy

    return [name,health,maxHealth,attack,energy,maxEnergy]

def IronFist():
    name = "Iron Fist"
    maxHealth = 130
    health = maxHealth
    attack = 50
    maxEnergy = 100
    energy = maxEnergy

    return [name,health,maxHealth,attack,energy,maxEnergy]

def OrangeClockwork():
    name = "Orange Clockwork"
    maxHealth = 60
    health = maxHealth
    attack = 20
    maxEnergy = 40
    energy = maxEnergy

    return [name,health,maxHealth,attack,energy,maxEnergy]

def SoylentGreen():
    name = "Soylent Green"
    maxHealth = 75
    health = maxHealth
    attack = 35
    maxEnergy = 75
    energy = maxEnergy

    return [name,health,maxHealth,attack,energy,maxEnergy]

def KingCrimson():
    name = "Crimson King"
    maxHealth = 140
    health = maxHealth
    attack = 40
    maxEnergy = 80
    energy = maxEnergy

    return [name,health,maxHealth,attack,energy,maxEnergy]
